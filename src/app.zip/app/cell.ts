export class Cell {
  constructor(public value: 'X' | 'O' | '') {}
}
