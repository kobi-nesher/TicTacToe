import { stringify } from 'querystring';

export class Player {
  constructor(public name: string, public score: number) {}
}
